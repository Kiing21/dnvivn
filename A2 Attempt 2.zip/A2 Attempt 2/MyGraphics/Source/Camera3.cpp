#include "Camera3.h"
#include "Application.h"
#include "Mtx44.h"

Camera3::Camera3()
{
	this->Height = 0.0f;
}

Camera3::~Camera3()
{
}

void Camera3::Init(const Vector3& pos, const Vector3& target, const Vector3& up, float dist)
{
	this->position = defaultPosition = pos;
	this->target = defaultTarget = target;
	Vector3 view = (target - position).Normalized();
	Vector3 right = view.Cross(up);
	right.y = 0;
	right.Normalize();
	this->up = defaultUp = right.Cross(view).Normalized();
	PreviousAngle = 0;
	this->dist = dist;
}

void Camera3::Update(float Angle, float x,float y, float z, bool front)
{
	
	Vector3 NewPos = this->target;
	if (!front)
	{
		NewPos.Set(x - dist * cos(Angle), y + 10.0f, z - dist * sin(Angle));
	}
	else
	{
		NewPos.Set(x +dist * cos(Angle), y + 10.0f, z + dist * sin(Angle));
	}
	
	this->position = NewPos;
	Vector3 NewTarget = this->defaultTarget;
	NewTarget.Set(x, y, z);
	this->target = NewTarget;
	Vector3 view = (target - position).Normalized();
	Vector3 right = view.Cross(up);
	right.y = 0;
	right.Normalize();
	up = right.Cross(view).Normalized();
}

void Camera3::Reset()
{
	position = defaultPosition;
	target = defaultTarget;
	up = defaultUp;
}